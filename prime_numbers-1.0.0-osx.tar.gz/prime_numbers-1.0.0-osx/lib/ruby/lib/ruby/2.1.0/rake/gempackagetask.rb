fail "ERROR: 'rake/gempackagetask' is obsolete and no longer supported. " +
  "Use 'rubygems/packagetask' instead."
